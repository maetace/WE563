package com.example.workshop_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
