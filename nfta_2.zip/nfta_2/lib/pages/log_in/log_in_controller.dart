import 'package:get/get.dart';

class LogInController extends GetxController {
  // Add your controller logic here
}
